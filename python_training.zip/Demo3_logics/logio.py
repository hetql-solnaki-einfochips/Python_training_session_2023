
mark=int(input("Enter marks"))

if mark>=90:
    print("Grade A")
elif mark>=80 and mark<=90:
    print("Grade B")
elif mark>=60 and mark<=70:
    print("Grade C")
else:
    print("Grade D")
