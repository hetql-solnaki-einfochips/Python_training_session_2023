def volume_sphere(radius):
    return 4/3*3.14*radius*radius*radius

def volume_Pyramid(Area, Height):
    return 1/3*Area*Height

def volume_cuboid(Length, Height, Weidth):
    return Length*Height*Weidth


