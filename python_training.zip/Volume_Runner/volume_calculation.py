from Volume_Task import Main_function

Res=Main_function.volume_sphere(10)
Res1=Main_function.volume_cuboid(2,3,4)
Res2=Main_function.volume_Pyramid(20,5)

print("The volume of Spere is", Res)

print("The volume of cuboid is", Res1)
print("The volume of Pyramid is", Res2)