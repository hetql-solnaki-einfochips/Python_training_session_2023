color=['Red', 'Green','Yellow']

print((color))
color.append('Blue')
print((color))
color.insert(2,'Pink')
print((color))

color.remove('Blue')
print((color))



dict={'STudent Name':'Hetal', 'Marks':[90,98,78,91], 'Mail ID':'hetal@gmail.com'}
print(dict['Marks'])