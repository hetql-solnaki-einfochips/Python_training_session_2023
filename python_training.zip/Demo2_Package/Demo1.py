from Area import calculation

result = calculation.cir_area(20)
result1 = calculation.tri_area(10,5)
result2 = calculation.squre_area(20)

print('The area of circle is',result)
print('The area of triangle is',result1)
print('The area of squre is',result2)